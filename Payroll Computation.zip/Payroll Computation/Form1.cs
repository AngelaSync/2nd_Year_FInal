﻿using System.Data;
using System.Data.SQLite;
using System.Windows.Forms;

namespace Payroll_Computation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            CreateDatabase();    // create DB if it doesn't exist
            LoadPayrolls();      // optionally load records into DataGridView
        }

        private void CreateDatabase()
        {
            if (!File.Exists("PayrollDB.db"))
            {
                SQLiteConnection.CreateFile("PayrollDB.db");
                using (var con = new SQLiteConnection("Data Source=PayrollDB.db;Version=3;"))
                {
                    con.Open();
                    string sql = @"CREATE TABLE EmployeePayroll (
                                    Id INTEGER PRIMARY KEY AUTOINCREMENT,
                                    EmployeeName TEXT,
                                    RatePerHour REAL,
                                    HoursWorked REAL,
                                    Deductions REAL,
                                    GrossPay REAL,
                                    Tax REAL,
                                    NetPay REAL
                                );";
                    SQLiteCommand cmd = new SQLiteCommand(sql, con);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Load saved payrolls into DataGridView
        private void LoadPayrolls()
        {
            using (var con = new SQLiteConnection("Data Source=PayrollDB.db;Version=3;"))
            {
                con.Open();
                var da = new SQLiteDataAdapter("SELECT * FROM EmployeePayroll", con);
                var dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;

                // Hide ID column
                dataGridView1.Columns["Id"].Visible = false;

                // Rename column headers for display
                dataGridView1.Columns["EmployeeName"].HeaderText = "Employee Name";
                dataGridView1.Columns["RatePerHour"].HeaderText = "Rate per Hour";
                dataGridView1.Columns["HoursWorked"].HeaderText = "Hours Worked";
                dataGridView1.Columns["Deductions"].HeaderText = "Deductions";
                dataGridView1.Columns["GrossPay"].HeaderText = "Gross Pay";
                dataGridView1.Columns["Tax"].HeaderText = "Tax (10%)";
                dataGridView1.Columns["NetPay"].HeaderText = "Net Pay";

                // Optional: Auto-size for neat layout
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            }
        }

        
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnCompute_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate inputs
                if (string.IsNullOrWhiteSpace(txtName.Text))
                {
                    MessageBox.Show("Please enter employee name.");
                    return;
                }

                if (!double.TryParse(txtRate.Text, out double rate) || rate <= 0)
                {
                    MessageBox.Show("Enter a valid Rate per Hour.");
                    return;
                }

                if (!double.TryParse(txtHours.Text, out double hours) || hours <= 0)
                {
                    MessageBox.Show("Enter a valid Hours Worked.");
                    return;
                }

                if (!double.TryParse(txtDeductions.Text, out double deductions) || deductions < 0)
                {
                    MessageBox.Show("Enter a valid Deductions amount.");
                    return;
                }

                // Create Payroll object
                Payroll employee = new Payroll()
                {
                    EmployeeName = txtName.Text,
                    RatePerHour = rate,
                    HoursWorked = hours,
                    Deductions = deductions
                };

                // Display computed results
                lblOutputGross.Text = $"₱{employee.GrossPay:N2}";
                lblOutputTax.Text = $"₱{employee.Tax:N2}";
                lblOutputNet.Text = $"₱{employee.NetPay:N2}";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtName.Clear();
            txtRate.Clear();
            txtHours.Clear();
            txtDeductions.Clear();
            lblOutputGross.Text = "";
            lblOutputTax.Text = "";
            lblOutputNet.Text = "";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Input validation
            if (string.IsNullOrWhiteSpace(txtName.Text) ||
                string.IsNullOrWhiteSpace(txtRate.Text) ||
                string.IsNullOrWhiteSpace(txtHours.Text) ||
                string.IsNullOrWhiteSpace(txtDeductions.Text))
            {
                MessageBox.Show("Please fill in all fields.");
                return;
            }

            if (!double.TryParse(txtRate.Text, out double rate) ||
                !double.TryParse(txtHours.Text, out double hours) ||
                !double.TryParse(txtDeductions.Text, out double deductions))
            {
                MessageBox.Show("Enter valid numbers for rate, hours, and deductions.");
                return;
            }

            // Compute payroll
            double gross = rate * hours;
            double tax = gross * 0.1;
            double net = gross - tax - deductions;

            lblOutputGross.Text = $"₱ {gross:0.00}";
            lblOutputTax.Text = $"₱ {tax:0.00}";
            lblOutputNet.Text = $"₱ {net:0.00}";

            // Save to database
            using (var con = new SQLiteConnection("Data Source=PayrollDB.db;Version=3;"))
            {
                con.Open();
                string query = @"INSERT INTO EmployeePayroll 
                        (EmployeeName, RatePerHour, HoursWorked, Deductions, GrossPay, Tax, NetPay)
                        VALUES (@name, @rate, @hours, @deduct, @gross, @tax, @net)";
                using (var cmd = new SQLiteCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@name", txtName.Text);
                    cmd.Parameters.AddWithValue("@rate", rate);
                    cmd.Parameters.AddWithValue("@hours", hours);
                    cmd.Parameters.AddWithValue("@deduct", deductions);
                    cmd.Parameters.AddWithValue("@gross", gross);
                    cmd.Parameters.AddWithValue("@tax", tax);
                    cmd.Parameters.AddWithValue("@net", net);
                    cmd.ExecuteNonQuery();
                }
            }

            // Refresh DataGridView
            LoadPayrolls();

            MessageBox.Show("Saved successfully!");
        }
    }
}


