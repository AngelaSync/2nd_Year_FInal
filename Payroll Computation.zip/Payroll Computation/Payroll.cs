﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Payroll_Computation
{
    public class Payroll
    {
        public string? EmployeeName { get; set; } //This tells the compiler it’s allowed to be null until assigned a value later
        public double RatePerHour { get; set; }
        public double HoursWorked { get; set; }
        public double Deductions { get; set; }

        private const double TAX_RATE = 0.10; // 10% tax rate

        //computed properties
        public double GrossPay
        {
            get { return RatePerHour * HoursWorked; }
        }
        public double Tax
        {
            get { return GrossPay * TAX_RATE; }
        }
        public double NetPay
        {
            get { return GrossPay - Tax - Deductions; }
        }

    }
}
