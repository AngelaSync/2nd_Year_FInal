﻿namespace Payroll_Computation
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblName = new Label();
            lblRate = new Label();
            lblHours = new Label();
            lblDeduct = new Label();
            groupBox2 = new GroupBox();
            lblOutputNet = new Label();
            lblOutputTax = new Label();
            lblOutputGross = new Label();
            lblNet = new Label();
            lblTax = new Label();
            label4 = new Label();
            lblGross = new Label();
            groupBox1 = new GroupBox();
            btnSave = new Button();
            label3 = new Label();
            txtName = new TextBox();
            txtDeductions = new TextBox();
            txtHours = new TextBox();
            txtRate = new TextBox();
            btnClear = new Button();
            btnCompute = new Button();
            label1 = new Label();
            dataGridView1 = new DataGridView();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Font = new Font("Sylfaen", 9F);
            lblName.Location = new Point(31, 55);
            lblName.Name = "lblName";
            lblName.Size = new Size(84, 16);
            lblName.TabIndex = 0;
            lblName.Text = "Emplyee Name:";
            // 
            // lblRate
            // 
            lblRate.AutoSize = true;
            lblRate.Font = new Font("Sylfaen", 9F);
            lblRate.Location = new Point(31, 86);
            lblRate.Name = "lblRate";
            lblRate.Size = new Size(81, 16);
            lblRate.TabIndex = 1;
            lblRate.Text = "Rate per Hour:";
            // 
            // lblHours
            // 
            lblHours.AutoSize = true;
            lblHours.Font = new Font("Sylfaen", 9F);
            lblHours.Location = new Point(31, 117);
            lblHours.Name = "lblHours";
            lblHours.Size = new Size(86, 16);
            lblHours.TabIndex = 2;
            lblHours.Text = "Worked Hours: ";
            // 
            // lblDeduct
            // 
            lblDeduct.AutoSize = true;
            lblDeduct.Font = new Font("Sylfaen", 9F);
            lblDeduct.Location = new Point(30, 146);
            lblDeduct.Name = "lblDeduct";
            lblDeduct.Size = new Size(65, 16);
            lblDeduct.TabIndex = 3;
            lblDeduct.Text = "Deductions:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lblOutputNet);
            groupBox2.Controls.Add(lblOutputTax);
            groupBox2.Controls.Add(lblOutputGross);
            groupBox2.Controls.Add(lblNet);
            groupBox2.Controls.Add(lblTax);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(lblGross);
            groupBox2.Location = new Point(1, 230);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(415, 188);
            groupBox2.TabIndex = 5;
            groupBox2.TabStop = false;
            // 
            // lblOutputNet
            // 
            lblOutputNet.BackColor = SystemColors.Window;
            lblOutputNet.Font = new Font("Sylfaen", 9F);
            lblOutputNet.Location = new Point(123, 120);
            lblOutputNet.Name = "lblOutputNet";
            lblOutputNet.Size = new Size(142, 23);
            lblOutputNet.TabIndex = 23;
            lblOutputNet.Text = "                               ";
            // 
            // lblOutputTax
            // 
            lblOutputTax.BackColor = SystemColors.Window;
            lblOutputTax.Font = new Font("Sylfaen", 9F);
            lblOutputTax.Location = new Point(123, 89);
            lblOutputTax.Name = "lblOutputTax";
            lblOutputTax.Size = new Size(142, 23);
            lblOutputTax.TabIndex = 22;
            lblOutputTax.Text = "                               ";
            lblOutputTax.Click += label5_Click;
            // 
            // lblOutputGross
            // 
            lblOutputGross.BackColor = SystemColors.Window;
            lblOutputGross.Font = new Font("Sylfaen", 9F);
            lblOutputGross.Location = new Point(123, 57);
            lblOutputGross.Name = "lblOutputGross";
            lblOutputGross.Size = new Size(142, 25);
            lblOutputGross.TabIndex = 21;
            lblOutputGross.Text = "                               ";
            // 
            // lblNet
            // 
            lblNet.AutoSize = true;
            lblNet.Font = new Font("Sylfaen", 9F);
            lblNet.Location = new Point(37, 124);
            lblNet.Name = "lblNet";
            lblNet.Size = new Size(49, 16);
            lblNet.TabIndex = 19;
            lblNet.Text = "Net Pay:";
            // 
            // lblTax
            // 
            lblTax.AutoSize = true;
            lblTax.Font = new Font("Sylfaen", 9F);
            lblTax.Location = new Point(35, 94);
            lblTax.Name = "lblTax";
            lblTax.Size = new Size(60, 16);
            lblTax.TabIndex = 17;
            lblTax.Text = "Tax (10%):";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Tw Cen MT Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.RosyBrown;
            label4.Location = new Point(170, 17);
            label4.Name = "label4";
            label4.Size = new Size(66, 22);
            label4.TabIndex = 16;
            label4.Text = "RESULTS";
            // 
            // lblGross
            // 
            lblGross.AutoSize = true;
            lblGross.Font = new Font("Sylfaen", 9F);
            lblGross.Location = new Point(35, 64);
            lblGross.Name = "lblGross";
            lblGross.Size = new Size(59, 16);
            lblGross.TabIndex = 14;
            lblGross.Text = "Gross Pay:";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnSave);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(txtName);
            groupBox1.Controls.Add(txtDeductions);
            groupBox1.Controls.Add(lblDeduct);
            groupBox1.Controls.Add(txtHours);
            groupBox1.Controls.Add(txtRate);
            groupBox1.Controls.Add(btnClear);
            groupBox1.Controls.Add(btnCompute);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(1, 1);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(415, 223);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            // 
            // btnSave
            // 
            btnSave.BackColor = Color.MistyRose;
            btnSave.FlatStyle = FlatStyle.Flat;
            btnSave.Location = new Point(314, 183);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(95, 26);
            btnSave.TabIndex = 15;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = false;
            btnSave.Click += btnSave_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Tw Cen MT Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.RosyBrown;
            label3.Location = new Point(242, 125);
            label3.Name = "label3";
            label3.Size = new Size(0, 22);
            label3.TabIndex = 14;
            // 
            // txtName
            // 
            txtName.Font = new Font("Sylfaen", 9F);
            txtName.Location = new Point(123, 51);
            txtName.Name = "txtName";
            txtName.Size = new Size(142, 23);
            txtName.TabIndex = 13;
            // 
            // txtDeductions
            // 
            txtDeductions.Font = new Font("Sylfaen", 9F);
            txtDeductions.Location = new Point(123, 140);
            txtDeductions.Name = "txtDeductions";
            txtDeductions.Size = new Size(142, 23);
            txtDeductions.TabIndex = 12;
            // 
            // txtHours
            // 
            txtHours.Font = new Font("Sylfaen", 9F);
            txtHours.Location = new Point(123, 111);
            txtHours.Name = "txtHours";
            txtHours.Size = new Size(142, 23);
            txtHours.TabIndex = 11;
            // 
            // txtRate
            // 
            txtRate.Font = new Font("Sylfaen", 9F);
            txtRate.Location = new Point(123, 81);
            txtRate.Name = "txtRate";
            txtRate.Size = new Size(142, 23);
            txtRate.TabIndex = 10;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.MistyRose;
            btnClear.FlatStyle = FlatStyle.Flat;
            btnClear.Location = new Point(123, 183);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(95, 26);
            btnClear.TabIndex = 9;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = false;
            btnClear.Click += btnClear_Click;
            // 
            // btnCompute
            // 
            btnCompute.BackColor = Color.MistyRose;
            btnCompute.FlatStyle = FlatStyle.Flat;
            btnCompute.Location = new Point(22, 183);
            btnCompute.Name = "btnCompute";
            btnCompute.Size = new Size(95, 26);
            btnCompute.TabIndex = 8;
            btnCompute.Text = "Compute Pay";
            btnCompute.UseVisualStyleBackColor = false;
            btnCompute.Click += btnCompute_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tw Cen MT Condensed", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.RosyBrown;
            label1.Location = new Point(128, 8);
            label1.Name = "label1";
            label1.Size = new Size(175, 22);
            label1.TabIndex = 7;
            label1.Text = "PAYROLL COMPUTATION";
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.MistyRose;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(441, 20);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(421, 409);
            dataGridView1.TabIndex = 7;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Lavender;
            ClientSize = new Size(874, 450);
            Controls.Add(dataGridView1);
            Controls.Add(groupBox2);
            Controls.Add(lblHours);
            Controls.Add(lblRate);
            Controls.Add(lblName);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Payroll Computer";
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblName;
        private Label lblRate;
        private Label lblHours;
        private Label lblDeduct;
        private GroupBox groupBox2;
        private GroupBox groupBox1;
        private Label label1;
        private TextBox txtName;
        private TextBox txtDeductions;
        private TextBox txtHours;
        private TextBox txtRate;
        private Button btnClear;
        private Button btnCompute;
        private Label lblTax;
        private Label label4;
        private Label lblGross;
        private Label label3;
        private Label lblNet;
        private Label lblOutputTax;
        private Label lblOutputGross;
        private Label lblOutputNet;
        private DataGridView dataGridView1;
        private Button btnSave;
    }
}
