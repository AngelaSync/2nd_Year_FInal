using System.Windows.Forms;
using System.Xml.Linq;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace StudentInfoApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void openFileDialog1_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void BtnUpld_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            openFileDialog1.Title = "Select a Profile Image"; // Dialog Title
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName); //Getting the Image File
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

                Properties.Settings.Default.ProfileImagePath = openFileDialog1.FileName;
                Properties.Settings.Default.Save();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string imagePath = Properties.Settings.Default.ProfileImagePath;
            if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
            {
                pictureBox1.Image = Image.FromFile(imagePath);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void BtnSubmt_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(textBox_FirstName.Text) ||
     !System.Text.RegularExpressions.Regex.IsMatch(textBox_FirstName.Text, @"^[A-Za-z][A-Za-z.\s]{1,}$"))
            {
                MessageBox.Show("Please enter a valid first name (letters, spaces, and periods only).",
                                "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }


            if (string.IsNullOrWhiteSpace(textBox_LastName.Text) ||
                !System.Text.RegularExpressions.Regex.IsMatch(textBox_LastName.Text, @"^[A-Za-z][A-Za-z.\s]{1,}$"))
            {
                MessageBox.Show("Please enter a valid last name (letters, spaces, and periods only).",
                                "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox_LastName.Focus();
                return;
            }

            if (!maskedTextBox1.MaskFull ||
            !System.Text.RegularExpressions.Regex.IsMatch(maskedTextBox1.Text, @"^\(\d{3}\) \d{3}-\d{4}$"))
            {
                MessageBox.Show("Please enter a valid phone number in the format (123) 456-7890.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                maskedTextBox1.Focus();
                return;
            }

            if (!radioButton_M.Checked && !radioButton_F.Checked)
            {
                MessageBox.Show("Please select a gender.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var today = DateTime.Today;
            var dob = dateTimePicker1.Value.Date;
            var age = today.Year - dob.Year;
            if (dob > today.AddYears(-age)) age--;

            if (age < 13)
            {
                MessageBox.Show("You must be at least 13 years old.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                dateTimePicker1.Focus();
                return;
            }



            // Validate Address (letters and spaces only)
            if (string.IsNullOrWhiteSpace(textBox_Address.Text) ||
            !System.Text.RegularExpressions.Regex.IsMatch(textBox_Address.Text, @"^[A-Za-z\s]+$"))
            {
                MessageBox.Show("Please enter a valid Address (letters and spaces only).",
                                "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox_Address.Focus();
                return;
            }


            if (pictureBox1.Image == null)
            {
                MessageBox.Show("Please upload a profile image.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (comboBox1.SelectedIndex < 0)
            {
                MessageBox.Show("Please select a course.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                comboBox1.Focus();
                return;
            }

            if (!checkBox_Reading.Checked && !checkBox_Music.Checked &&
                !checkBox_Sleep.Checked && !checkBox_Movies.Checked)
            {
                MessageBox.Show("Please select at least one interest.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (trackBar_Satisfy.Value == trackBar_Satisfy.Minimum)
            {
                lbl_Satisfy.Text = $"Satisfaction: {trackBar_Satisfy.Value}";
                MessageBox.Show("Please indicate your satisfaction level.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                trackBar_Satisfy.Focus();
                return;
            }

            // If all inputs are valid, copy them to "Saved" labels in the summary tab
            Saved_fname.Text = textBox_FirstName.Text;
            Saved_lname.Text = textBox_LastName.Text;
            Saved_phone.Text = maskedTextBox1.Text;
            Saved_gender.Text = radioButton_M.Checked ? "Male" : "Female";
            Saved_dob.Text = dateTimePicker1.Value.ToShortDateString();
            Saved_studentID.Text = maskedTextBox2.Text;
            Saved_address.Text = textBox_Address.Text;


            // DOB
            Saved_dob.Text = dateTimePicker1.Value.ToShortDateString();


            // Course
            if (comboBox1.SelectedIndex >= 0)
                Saved_course.Text = comboBox1.SelectedItem.ToString();

            // Interests
            List<string> interests = new List<string>();
            if (checkBox_Reading.Checked) interests.Add("Reading");
            if (checkBox_Music.Checked) interests.Add("Music");
            if (checkBox_Sleep.Checked) interests.Add("Sleep");
            if (checkBox_Movies.Checked) interests.Add("Movies");
            Saved_listbox.Text = string.Join(", ", interests);
            Saved_listbox.Items.Clear();
            Saved_listbox.Items.AddRange(interests.ToArray());

            // Satisfaction level
            Saved_satisfaction.Text = trackBar_Satisfy.Value.ToString();

            // Profile image
            if (pictureBox1.Image != null)
            {
               Saved_picbox.Image = pictureBox1.Image;
            }

            // Switch to summary tab after saving
            tabctrl1.SelectedTab = tabctrlsumm;

            MessageBox.Show("All inputs copied to summary!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            MessageBox.Show("All inputs are valid!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }

        private void Saved_fname_TextChanged(object sender, EventArgs e)
        {
            Saved_fname.Text = textBox_FirstName.Text;
        }

        private void tabctrlsumm_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}



