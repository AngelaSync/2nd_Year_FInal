﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentInfoApp
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            /*string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (username == "admin" && password == "1234")
            {
                this.Hide();
                Form1 StudentInfoApp = new Form1();
                StudentInfoApp.Show();
            }
            else
            {
                MessageBox.Show("Invalid username or password");
            }*/

            var connection = new SQLiteConnection("Data Source=studentinfo.db;Version=3;");
            connection.Open();

            var cmd = new SQLiteCommand(
                "SELECT COUNT(1) FROM Users WHERE Username = @u AND Password = @p",
                connection);

            cmd.Parameters.AddWithValue("@u", txtUsername.Text.Trim());
            cmd.Parameters.AddWithValue("@p", txtPassword.Text.Trim());

            if (Convert.ToInt32(cmd.ExecuteScalar()) > 0)
            {
                MessageBox.Show("Login successful!", "Success");
                this.Hide();
                Form1 mainForm = new Form1();
                mainForm.Show();

            }
        
            else
            {
                MessageBox.Show("Invalid username or password.", "Error");

            }




        }
    }
}
    

