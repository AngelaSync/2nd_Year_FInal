using System;
using System.Windows.Forms;
using System.Data.SQLite;

namespace StudentInfoApp
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
          using (var connection = new SQLiteConnection("Data Source=studentinfo.db;Version=3;"))
            {
                connection.Open();
                new SQLiteCommand(
                     "CREATE TABLE IF NOT EXISTS Users(Id INTEGER PRIMARY KEY, Username TEXT, Password TEXT)", 
                     connection ).ExecuteNonQuery();     

                new SQLiteCommand("INSERT INTO USERS(Username, Password)"+
                    "select 'admin','1234' WHERE NOT EXISTS (SELECT 1 FROM Users WHERE Username = 'admin')",
                    connection ).ExecuteNonQuery();
            }



            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Login());
        }
    }
}