﻿namespace StudentInfoApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabctrl1 = new TabControl();
            tabctrlinfo = new TabPage();
            pictureBox1 = new PictureBox();
            BtnSubmt = new Button();
            BtnUpld = new Button();
            groupBox_Acad = new GroupBox();
            checkBox1 = new CheckBox();
            trackBar_Satisfy = new TrackBar();
            lbl_Satisfy = new Label();
            checkBox_Reading = new CheckBox();
            checkBox_Music = new CheckBox();
            checkBox_Sleep = new CheckBox();
            checkBox_Movies = new CheckBox();
            lbl_Int = new Label();
            comboBox1 = new ComboBox();
            lbl_Course = new Label();
            groupBox_Pers = new GroupBox();
            textBox_Address = new TextBox();
            maskedTextBox2 = new MaskedTextBox();
            lbl_Address = new Label();
            lbl_StudentID = new Label();
            dateTimePicker1 = new DateTimePicker();
            lbl_DOB = new Label();
            radioButton_M = new RadioButton();
            radioButton_F = new RadioButton();
            lbl_Gender = new Label();
            textBox_LastName = new TextBox();
            textBox_FirstName = new TextBox();
            maskedTextBox1 = new MaskedTextBox();
            lbl_Phone = new Label();
            lbl_LastName = new Label();
            lbl_FirstName = new Label();
            tabctrlsumm = new TabPage();
            Saved_picbox = new PictureBox();
            Saved_listbox = new ListBox();
            Saved_address = new TextBox();
            Saved_studentID = new TextBox();
            Saved_dob = new TextBox();
            Saved_gender = new TextBox();
            Saved_phone = new TextBox();
            Saved_lname = new TextBox();
            Saved_fname = new TextBox();
            label10 = new Label();
            label9 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            SavedProfilePic = new Label();
            SavedFirstName = new Label();
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            Saved_satisfaction = new TextBox();
            Saved_course = new TextBox();
            label8 = new Label();
            tabctrlsett = new TabPage();
            openFileDialog1 = new OpenFileDialog();
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            tabctrl1.SuspendLayout();
            tabctrlinfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox_Acad.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)trackBar_Satisfy).BeginInit();
            groupBox_Pers.SuspendLayout();
            tabctrlsumm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Saved_picbox).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // tabctrl1
            // 
            tabctrl1.Controls.Add(tabctrlinfo);
            tabctrl1.Controls.Add(tabctrlsumm);
            tabctrl1.Controls.Add(tabctrlsett);
            tabctrl1.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabctrl1.Location = new Point(-9, 2);
            tabctrl1.Margin = new Padding(3, 2, 3, 2);
            tabctrl1.Name = "tabctrl1";
            tabctrl1.SelectedIndex = 0;
            tabctrl1.Size = new Size(703, 410);
            tabctrl1.TabIndex = 0;
            // 
            // tabctrlinfo
            // 
            tabctrlinfo.BackColor = Color.MistyRose;
            tabctrlinfo.Controls.Add(pictureBox1);
            tabctrlinfo.Controls.Add(BtnSubmt);
            tabctrlinfo.Controls.Add(BtnUpld);
            tabctrlinfo.Controls.Add(groupBox_Acad);
            tabctrlinfo.Controls.Add(groupBox_Pers);
            tabctrlinfo.Location = new Point(4, 24);
            tabctrlinfo.Margin = new Padding(3, 2, 3, 2);
            tabctrlinfo.Name = "tabctrlinfo";
            tabctrlinfo.Padding = new Padding(3, 2, 3, 2);
            tabctrlinfo.Size = new Size(695, 382);
            tabctrlinfo.TabIndex = 0;
            tabctrlinfo.Text = "Info Form";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.LightSteelBlue;
            pictureBox1.Location = new Point(63, 276);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(122, 97);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // BtnSubmt
            // 
            BtnSubmt.BackColor = Color.Thistle;
            BtnSubmt.Location = new Point(486, 276);
            BtnSubmt.Margin = new Padding(3, 2, 3, 2);
            BtnSubmt.Name = "BtnSubmt";
            BtnSubmt.Size = new Size(131, 48);
            BtnSubmt.TabIndex = 3;
            BtnSubmt.Text = "Submit";
            BtnSubmt.UseVisualStyleBackColor = false;
            BtnSubmt.Click += BtnSubmt_Click;
            // 
            // BtnUpld
            // 
            BtnUpld.BackColor = Color.Thistle;
            BtnUpld.Location = new Point(206, 296);
            BtnUpld.Margin = new Padding(3, 2, 3, 2);
            BtnUpld.Name = "BtnUpld";
            BtnUpld.Size = new Size(119, 39);
            BtnUpld.TabIndex = 2;
            BtnUpld.Text = "Upload Picture";
            BtnUpld.UseVisualStyleBackColor = false;
            BtnUpld.Click += BtnUpld_Click;
            // 
            // groupBox_Acad
            // 
            groupBox_Acad.Controls.Add(checkBox1);
            groupBox_Acad.Controls.Add(trackBar_Satisfy);
            groupBox_Acad.Controls.Add(lbl_Satisfy);
            groupBox_Acad.Controls.Add(checkBox_Reading);
            groupBox_Acad.Controls.Add(checkBox_Music);
            groupBox_Acad.Controls.Add(checkBox_Sleep);
            groupBox_Acad.Controls.Add(checkBox_Movies);
            groupBox_Acad.Controls.Add(lbl_Int);
            groupBox_Acad.Controls.Add(comboBox1);
            groupBox_Acad.Controls.Add(lbl_Course);
            groupBox_Acad.Location = new Point(398, 2);
            groupBox_Acad.Margin = new Padding(3, 2, 3, 2);
            groupBox_Acad.Name = "groupBox_Acad";
            groupBox_Acad.Padding = new Padding(3, 2, 3, 2);
            groupBox_Acad.Size = new Size(298, 230);
            groupBox_Acad.TabIndex = 1;
            groupBox_Acad.TabStop = false;
            groupBox_Acad.Text = "Academic Information";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(215, 92);
            checkBox1.Margin = new Padding(3, 2, 3, 2);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(70, 19);
            checkBox1.TabIndex = 9;
            checkBox1.Text = "Baking";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // trackBar_Satisfy
            // 
            trackBar_Satisfy.LargeChange = 1;
            trackBar_Satisfy.Location = new Point(19, 175);
            trackBar_Satisfy.Margin = new Padding(3, 2, 3, 2);
            trackBar_Satisfy.Name = "trackBar_Satisfy";
            trackBar_Satisfy.Size = new Size(272, 45);
            trackBar_Satisfy.TabIndex = 1;
            // 
            // lbl_Satisfy
            // 
            lbl_Satisfy.AutoSize = true;
            lbl_Satisfy.Location = new Point(117, 144);
            lbl_Satisfy.Name = "lbl_Satisfy";
            lbl_Satisfy.Size = new Size(82, 15);
            lbl_Satisfy.TabIndex = 7;
            lbl_Satisfy.Text = "Satisfaction";
            // 
            // checkBox_Reading
            // 
            checkBox_Reading.AutoSize = true;
            checkBox_Reading.Location = new Point(122, 106);
            checkBox_Reading.Margin = new Padding(3, 2, 3, 2);
            checkBox_Reading.Name = "checkBox_Reading";
            checkBox_Reading.Size = new Size(80, 19);
            checkBox_Reading.TabIndex = 6;
            checkBox_Reading.Text = "Reading";
            checkBox_Reading.UseVisualStyleBackColor = true;
            // 
            // checkBox_Music
            // 
            checkBox_Music.AutoSize = true;
            checkBox_Music.Location = new Point(40, 106);
            checkBox_Music.Margin = new Padding(3, 2, 3, 2);
            checkBox_Music.Name = "checkBox_Music";
            checkBox_Music.Size = new Size(64, 19);
            checkBox_Music.TabIndex = 5;
            checkBox_Music.Text = "Music";
            checkBox_Music.UseVisualStyleBackColor = true;
            // 
            // checkBox_Sleep
            // 
            checkBox_Sleep.AutoSize = true;
            checkBox_Sleep.Location = new Point(122, 79);
            checkBox_Sleep.Margin = new Padding(3, 2, 3, 2);
            checkBox_Sleep.Name = "checkBox_Sleep";
            checkBox_Sleep.Size = new Size(83, 19);
            checkBox_Sleep.TabIndex = 4;
            checkBox_Sleep.Text = "Sleeping";
            checkBox_Sleep.UseVisualStyleBackColor = true;
            // 
            // checkBox_Movies
            // 
            checkBox_Movies.AutoSize = true;
            checkBox_Movies.Location = new Point(39, 80);
            checkBox_Movies.Margin = new Padding(3, 2, 3, 2);
            checkBox_Movies.Name = "checkBox_Movies";
            checkBox_Movies.Size = new Size(71, 19);
            checkBox_Movies.TabIndex = 3;
            checkBox_Movies.Text = "Movies";
            checkBox_Movies.UseVisualStyleBackColor = true;
            // 
            // lbl_Int
            // 
            lbl_Int.AutoSize = true;
            lbl_Int.Location = new Point(19, 54);
            lbl_Int.Name = "lbl_Int";
            lbl_Int.Size = new Size(62, 15);
            lbl_Int.TabIndex = 2;
            lbl_Int.Text = "Interests";
            // 
            // comboBox1
            // 
            comboBox1.BackColor = Color.SeaShell;
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "BSIT", "BSCS", "BMMA" });
            comboBox1.Location = new Point(73, 27);
            comboBox1.Margin = new Padding(3, 2, 3, 2);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(133, 23);
            comboBox1.TabIndex = 1;
            comboBox1.Text = "Select";
            // 
            // lbl_Course
            // 
            lbl_Course.AutoSize = true;
            lbl_Course.Location = new Point(16, 28);
            lbl_Course.Name = "lbl_Course";
            lbl_Course.Size = new Size(52, 15);
            lbl_Course.TabIndex = 0;
            lbl_Course.Text = "Course";
            // 
            // groupBox_Pers
            // 
            groupBox_Pers.Controls.Add(textBox_Address);
            groupBox_Pers.Controls.Add(maskedTextBox2);
            groupBox_Pers.Controls.Add(lbl_Address);
            groupBox_Pers.Controls.Add(lbl_StudentID);
            groupBox_Pers.Controls.Add(dateTimePicker1);
            groupBox_Pers.Controls.Add(lbl_DOB);
            groupBox_Pers.Controls.Add(radioButton_M);
            groupBox_Pers.Controls.Add(radioButton_F);
            groupBox_Pers.Controls.Add(lbl_Gender);
            groupBox_Pers.Controls.Add(textBox_LastName);
            groupBox_Pers.Controls.Add(textBox_FirstName);
            groupBox_Pers.Controls.Add(maskedTextBox1);
            groupBox_Pers.Controls.Add(lbl_Phone);
            groupBox_Pers.Controls.Add(lbl_LastName);
            groupBox_Pers.Controls.Add(lbl_FirstName);
            groupBox_Pers.Location = new Point(5, 2);
            groupBox_Pers.Margin = new Padding(3, 2, 3, 2);
            groupBox_Pers.Name = "groupBox_Pers";
            groupBox_Pers.Padding = new Padding(3, 2, 3, 2);
            groupBox_Pers.Size = new Size(388, 290);
            groupBox_Pers.TabIndex = 0;
            groupBox_Pers.TabStop = false;
            groupBox_Pers.Text = "Personal Information";
            // 
            // textBox_Address
            // 
            textBox_Address.BackColor = Color.SeaShell;
            textBox_Address.Location = new Point(82, 227);
            textBox_Address.Margin = new Padding(3, 2, 3, 2);
            textBox_Address.Name = "textBox_Address";
            textBox_Address.Size = new Size(172, 21);
            textBox_Address.TabIndex = 14;
            // 
            // maskedTextBox2
            // 
            maskedTextBox2.BackColor = Color.SeaShell;
            maskedTextBox2.Location = new Point(113, 194);
            maskedTextBox2.Margin = new Padding(3, 2, 3, 2);
            maskedTextBox2.Mask = "00-0000-000";
            maskedTextBox2.Name = "maskedTextBox2";
            maskedTextBox2.Size = new Size(190, 21);
            maskedTextBox2.TabIndex = 13;
            // 
            // lbl_Address
            // 
            lbl_Address.AutoSize = true;
            lbl_Address.Location = new Point(21, 232);
            lbl_Address.Name = "lbl_Address";
            lbl_Address.Size = new Size(58, 15);
            lbl_Address.TabIndex = 12;
            lbl_Address.Text = "Address";
            // 
            // lbl_StudentID
            // 
            lbl_StudentID.AutoSize = true;
            lbl_StudentID.Location = new Point(21, 199);
            lbl_StudentID.Name = "lbl_StudentID";
            lbl_StudentID.Size = new Size(74, 15);
            lbl_StudentID.TabIndex = 11;
            lbl_StudentID.Text = "Student ID";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(119, 160);
            dateTimePicker1.Margin = new Padding(3, 2, 3, 2);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(234, 21);
            dateTimePicker1.TabIndex = 10;
            // 
            // lbl_DOB
            // 
            lbl_DOB.AutoSize = true;
            lbl_DOB.Location = new Point(19, 164);
            lbl_DOB.Name = "lbl_DOB";
            lbl_DOB.Size = new Size(87, 15);
            lbl_DOB.TabIndex = 9;
            lbl_DOB.Text = "Date of Birth";
            // 
            // radioButton_M
            // 
            radioButton_M.AutoSize = true;
            radioButton_M.Location = new Point(167, 128);
            radioButton_M.Margin = new Padding(3, 2, 3, 2);
            radioButton_M.Name = "radioButton_M";
            radioButton_M.Size = new Size(57, 19);
            radioButton_M.TabIndex = 8;
            radioButton_M.TabStop = true;
            radioButton_M.Text = "Male";
            radioButton_M.UseVisualStyleBackColor = true;
            // 
            // radioButton_F
            // 
            radioButton_F.AutoSize = true;
            radioButton_F.Location = new Point(82, 128);
            radioButton_F.Margin = new Padding(3, 2, 3, 2);
            radioButton_F.Name = "radioButton_F";
            radioButton_F.Size = new Size(73, 19);
            radioButton_F.TabIndex = 7;
            radioButton_F.TabStop = true;
            radioButton_F.Text = "Female";
            radioButton_F.UseVisualStyleBackColor = true;
            // 
            // lbl_Gender
            // 
            lbl_Gender.AutoSize = true;
            lbl_Gender.Location = new Point(18, 128);
            lbl_Gender.Name = "lbl_Gender";
            lbl_Gender.Size = new Size(54, 15);
            lbl_Gender.TabIndex = 6;
            lbl_Gender.Text = "Gender";
            // 
            // textBox_LastName
            // 
            textBox_LastName.BackColor = Color.SeaShell;
            textBox_LastName.Location = new Point(92, 58);
            textBox_LastName.Margin = new Padding(3, 2, 3, 2);
            textBox_LastName.Name = "textBox_LastName";
            textBox_LastName.Size = new Size(172, 21);
            textBox_LastName.TabIndex = 5;
            // 
            // textBox_FirstName
            // 
            textBox_FirstName.BackColor = Color.SeaShell;
            textBox_FirstName.Location = new Point(92, 28);
            textBox_FirstName.Margin = new Padding(3, 2, 3, 2);
            textBox_FirstName.Name = "textBox_FirstName";
            textBox_FirstName.Size = new Size(172, 21);
            textBox_FirstName.TabIndex = 4;
            // 
            // maskedTextBox1
            // 
            maskedTextBox1.BackColor = Color.SeaShell;
            maskedTextBox1.Location = new Point(71, 91);
            maskedTextBox1.Margin = new Padding(3, 2, 3, 2);
            maskedTextBox1.Mask = "(999) 000-0000";
            maskedTextBox1.Name = "maskedTextBox1";
            maskedTextBox1.Size = new Size(190, 21);
            maskedTextBox1.TabIndex = 3;
            // 
            // lbl_Phone
            // 
            lbl_Phone.AutoSize = true;
            lbl_Phone.Location = new Point(18, 96);
            lbl_Phone.Name = "lbl_Phone";
            lbl_Phone.Size = new Size(48, 15);
            lbl_Phone.TabIndex = 2;
            lbl_Phone.Text = "Phone";
            // 
            // lbl_LastName
            // 
            lbl_LastName.AutoSize = true;
            lbl_LastName.Location = new Point(16, 63);
            lbl_LastName.Name = "lbl_LastName";
            lbl_LastName.Size = new Size(76, 15);
            lbl_LastName.TabIndex = 1;
            lbl_LastName.Text = "Last Name";
            // 
            // lbl_FirstName
            // 
            lbl_FirstName.AutoSize = true;
            lbl_FirstName.Location = new Point(15, 29);
            lbl_FirstName.Name = "lbl_FirstName";
            lbl_FirstName.Size = new Size(77, 15);
            lbl_FirstName.TabIndex = 0;
            lbl_FirstName.Text = "First Name";
            // 
            // tabctrlsumm
            // 
            tabctrlsumm.BackColor = Color.MistyRose;
            tabctrlsumm.Controls.Add(Saved_picbox);
            tabctrlsumm.Controls.Add(Saved_listbox);
            tabctrlsumm.Controls.Add(Saved_address);
            tabctrlsumm.Controls.Add(Saved_studentID);
            tabctrlsumm.Controls.Add(Saved_dob);
            tabctrlsumm.Controls.Add(Saved_gender);
            tabctrlsumm.Controls.Add(Saved_phone);
            tabctrlsumm.Controls.Add(Saved_lname);
            tabctrlsumm.Controls.Add(Saved_fname);
            tabctrlsumm.Controls.Add(label10);
            tabctrlsumm.Controls.Add(label9);
            tabctrlsumm.Controls.Add(label7);
            tabctrlsumm.Controls.Add(label6);
            tabctrlsumm.Controls.Add(label5);
            tabctrlsumm.Controls.Add(label4);
            tabctrlsumm.Controls.Add(label3);
            tabctrlsumm.Controls.Add(label2);
            tabctrlsumm.Controls.Add(label1);
            tabctrlsumm.Controls.Add(SavedProfilePic);
            tabctrlsumm.Controls.Add(SavedFirstName);
            tabctrlsumm.Controls.Add(groupBox1);
            tabctrlsumm.Controls.Add(groupBox2);
            tabctrlsumm.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            tabctrlsumm.Location = new Point(4, 24);
            tabctrlsumm.Margin = new Padding(3, 2, 3, 2);
            tabctrlsumm.Name = "tabctrlsumm";
            tabctrlsumm.Padding = new Padding(3, 2, 3, 2);
            tabctrlsumm.Size = new Size(695, 382);
            tabctrlsumm.TabIndex = 1;
            tabctrlsumm.Text = "Summary";
            tabctrlsumm.Click += tabctrlsumm_Click;
            // 
            // Saved_picbox
            // 
            Saved_picbox.Location = new Point(49, 278);
            Saved_picbox.Name = "Saved_picbox";
            Saved_picbox.Size = new Size(137, 84);
            Saved_picbox.TabIndex = 34;
            Saved_picbox.TabStop = false;
            // 
            // Saved_listbox
            // 
            Saved_listbox.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Saved_listbox.FormattingEnabled = true;
            Saved_listbox.ItemHeight = 15;
            Saved_listbox.Location = new Point(421, 55);
            Saved_listbox.Name = "Saved_listbox";
            Saved_listbox.Size = new Size(120, 64);
            Saved_listbox.TabIndex = 31;
            // 
            // Saved_address
            // 
            Saved_address.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Saved_address.Location = new Point(121, 236);
            Saved_address.Name = "Saved_address";
            Saved_address.ReadOnly = true;
            Saved_address.Size = new Size(133, 21);
            Saved_address.TabIndex = 28;
            // 
            // Saved_studentID
            // 
            Saved_studentID.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Saved_studentID.Location = new Point(121, 204);
            Saved_studentID.Name = "Saved_studentID";
            Saved_studentID.ReadOnly = true;
            Saved_studentID.Size = new Size(133, 21);
            Saved_studentID.TabIndex = 27;
            // 
            // Saved_dob
            // 
            Saved_dob.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Saved_dob.Location = new Point(125, 166);
            Saved_dob.Name = "Saved_dob";
            Saved_dob.ReadOnly = true;
            Saved_dob.Size = new Size(129, 21);
            Saved_dob.TabIndex = 26;
            // 
            // Saved_gender
            // 
            Saved_gender.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Saved_gender.Location = new Point(121, 134);
            Saved_gender.Name = "Saved_gender";
            Saved_gender.ReadOnly = true;
            Saved_gender.Size = new Size(133, 21);
            Saved_gender.TabIndex = 25;
            // 
            // Saved_phone
            // 
            Saved_phone.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Saved_phone.Location = new Point(121, 96);
            Saved_phone.Name = "Saved_phone";
            Saved_phone.ReadOnly = true;
            Saved_phone.Size = new Size(133, 21);
            Saved_phone.TabIndex = 24;
            // 
            // Saved_lname
            // 
            Saved_lname.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Saved_lname.Location = new Point(121, 59);
            Saved_lname.Name = "Saved_lname";
            Saved_lname.ReadOnly = true;
            Saved_lname.Size = new Size(133, 21);
            Saved_lname.TabIndex = 23;
            // 
            // Saved_fname
            // 
            Saved_fname.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Saved_fname.Location = new Point(121, 24);
            Saved_fname.Name = "Saved_fname";
            Saved_fname.ReadOnly = true;
            Saved_fname.Size = new Size(133, 21);
            Saved_fname.TabIndex = 22;
            Saved_fname.TextChanged += Saved_fname_TextChanged;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            label10.Location = new Point(18, 236);
            label10.Name = "label10";
            label10.Size = new Size(58, 15);
            label10.TabIndex = 19;
            label10.Text = "Address";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            label9.Location = new Point(18, 204);
            label9.Name = "label9";
            label9.Size = new Size(74, 15);
            label9.TabIndex = 18;
            label9.Text = "Student ID";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            label7.Location = new Point(353, 59);
            label7.Name = "label7";
            label7.Size = new Size(62, 15);
            label7.TabIndex = 15;
            label7.Text = "Interests";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            label6.Location = new Point(353, 27);
            label6.Name = "label6";
            label6.Size = new Size(52, 15);
            label6.TabIndex = 14;
            label6.Text = "Course";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            label5.Location = new Point(18, 167);
            label5.Name = "label5";
            label5.Size = new Size(87, 15);
            label5.TabIndex = 13;
            label5.Text = "Date of Birth";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            label4.Location = new Point(18, 134);
            label4.Name = "label4";
            label4.Size = new Size(54, 15);
            label4.TabIndex = 12;
            label4.Text = "Gender";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            label3.Location = new Point(18, 99);
            label3.Name = "label3";
            label3.Size = new Size(48, 15);
            label3.TabIndex = 11;
            label3.Text = "Phone";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            label2.Location = new Point(18, 59);
            label2.Name = "label2";
            label2.Size = new Size(76, 15);
            label2.TabIndex = 10;
            label2.Text = "Last Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            label1.Location = new Point(18, 27);
            label1.Name = "label1";
            label1.Size = new Size(77, 15);
            label1.TabIndex = 9;
            label1.Text = "First Name";
            // 
            // SavedProfilePic
            // 
            SavedProfilePic.AutoSize = true;
            SavedProfilePic.Location = new Point(116, 242);
            SavedProfilePic.Name = "SavedProfilePic";
            SavedProfilePic.Size = new Size(0, 20);
            SavedProfilePic.TabIndex = 4;
            // 
            // SavedFirstName
            // 
            SavedFirstName.AutoSize = true;
            SavedFirstName.Font = new Font("Microsoft Sans Serif", 11.999999F, FontStyle.Bold);
            SavedFirstName.Location = new Point(230, 27);
            SavedFirstName.Name = "SavedFirstName";
            SavedFirstName.Size = new Size(0, 20);
            SavedFirstName.TabIndex = 0;
            // 
            // groupBox1
            // 
            groupBox1.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(5, 1);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(311, 284);
            groupBox1.TabIndex = 32;
            groupBox1.TabStop = false;
            groupBox1.Text = "Personal Information";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(Saved_satisfaction);
            groupBox2.Controls.Add(Saved_course);
            groupBox2.Controls.Add(label8);
            groupBox2.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(322, 1);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(377, 273);
            groupBox2.TabIndex = 33;
            groupBox2.TabStop = false;
            groupBox2.Text = "Academic Information";
            // 
            // Saved_satisfaction
            // 
            Saved_satisfaction.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Saved_satisfaction.Location = new Point(119, 149);
            Saved_satisfaction.Name = "Saved_satisfaction";
            Saved_satisfaction.ReadOnly = true;
            Saved_satisfaction.Size = new Size(100, 21);
            Saved_satisfaction.TabIndex = 34;
            Saved_satisfaction.TextChanged += textBox1_TextChanged;
            // 
            // Saved_course
            // 
            Saved_course.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            Saved_course.Location = new Point(99, 25);
            Saved_course.Name = "Saved_course";
            Saved_course.ReadOnly = true;
            Saved_course.Size = new Size(100, 21);
            Saved_course.TabIndex = 30;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold);
            label8.Location = new Point(31, 152);
            label8.Name = "label8";
            label8.Size = new Size(82, 15);
            label8.TabIndex = 16;
            label8.Text = "Satisfaction";
            // 
            // tabctrlsett
            // 
            tabctrlsett.Location = new Point(4, 24);
            tabctrlsett.Margin = new Padding(3, 2, 3, 2);
            tabctrlsett.Name = "tabctrlsett";
            tabctrlsett.Padding = new Padding(3, 2, 3, 2);
            tabctrlsett.Size = new Size(695, 382);
            tabctrlsett.TabIndex = 2;
            tabctrlsett.Text = "Settings";
            tabctrlsett.UseVisualStyleBackColor = true;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            openFileDialog1.FileOk += openFileDialog1_FileOk;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Lavender;
            ClientSize = new Size(700, 410);
            Controls.Add(tabctrl1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Student Info";
            Load += Form1_Load;
            tabctrl1.ResumeLayout(false);
            tabctrlinfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox_Acad.ResumeLayout(false);
            groupBox_Acad.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)trackBar_Satisfy).EndInit();
            groupBox_Pers.ResumeLayout(false);
            groupBox_Pers.PerformLayout();
            tabctrlsumm.ResumeLayout(false);
            tabctrlsumm.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)Saved_picbox).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabctrl1;
        private TabPage tabctrlinfo;
        private TabPage tabctrlsumm;
        private TabPage tabctrlsett;
        private GroupBox groupBox_Acad;
        private GroupBox groupBox_Pers;
        private Label lbl_FirstName;
        private Label lbl_LastName;
        private Label lbl_Phone;
        private TextBox textBox_LastName;
        private TextBox textBox_FirstName;
        private MaskedTextBox maskedTextBox1;
        private Button BtnSubmt;
        private Button btnUpld;
        private RadioButton radioButton_F;
        private Label lbl_Gender;
        private RadioButton radioButton_M;
        private PictureBox pictureBox1;
        private DateTimePicker dateTimePicker1;
        private Label lbl_DOB;
        private ComboBox comboBox1;
        private Label lbl_Course;
        private CheckBox checkBox_Reading;
        private CheckBox checkBox_Music;
        private CheckBox checkBox_Sleep;
        private CheckBox checkBox_Movies;
        private Label lbl_Int;
        private TrackBar trackBar_Satisfy;
        private Label lbl_Satisfy;
        private OpenFileDialog openFileDialog1;
        private Button BtnUpld;
        private Label SavedFirstName;
        private Label SavedProfilePic;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label Saved;
        private Label SavedProfilepicc;
        private Label SavedProfilePicc;
        private Label lbl_Address;
        private Label lbl_StudentID;
        private MaskedTextBox maskedTextBox2;
        private TextBox textBox_Address;
        private Label label10;
        private Label label9;
        private CheckBox checkBox1;
        private TextBox Saved_address;
        private TextBox Saved_studentID;
        private TextBox Saved_dob;
        private TextBox Saved_gender;
        private TextBox Saved_phone;
        private TextBox Saved_lname;
        private TextBox Saved_fname;
        private ListBox Saved_listbox;
        private TextBox Saved_course;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private TextBox Saved_satisfaction;
        private PictureBox Saved_picbox;
    }
}
