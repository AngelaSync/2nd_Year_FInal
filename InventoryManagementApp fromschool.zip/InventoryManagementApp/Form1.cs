﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementApp
{
    public partial class Form1 : Form
    {
        private List<Product> products = new List<Product>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string name = txtName.Text;
                string category = txtCategory.Text;
                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(category))
                {
                    MessageBox.Show("Name and Category cannot be empty.");
                    return;
                }

                int quantity = int.Parse(txtQuantity.Text);
                decimal price = decimal.Parse(txtPrice.Text);

                if (quantity < 0 || price < 0)
                {
                    MessageBox.Show("Quantity and Price cannot be negative.");
                    return;
                }

                // Create new product
                Product p = new Product(name, category, quantity, price);
                products.Add(p);

                // Update ListBox
                UpdateProductList();
                UpdateTotalValue();


                // Clear TextBoxes
                txtName.Clear();
                txtCategory.Clear();
                txtQuantity.Clear();
                txtPrice.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }


        }

        private void btnRemove_Click_1(object sender, EventArgs e)
        {
            if (lstProducts.SelectedIndex >= 0)
            {
                products.RemoveAt(lstProducts.SelectedIndex);
                UpdateProductList();
            }
            else
            {
                MessageBox.Show("Select a product to remove.");
            }
        }
        //private void btnRemove_Click(object sender, EventArgs e)
        //{

        //}
        private void UpdateProductList()
        {
            lstProducts.Items.Clear();
            foreach (Product p in products)
            {
                lstProducts.Items.Add(p.ToString());

            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            products.Clear();
            UpdateProductList();
        }

        private void lblTotalValue_Click(object sender, EventArgs e)
        {
            decimal totalPrice = products.Sum(p => p.Price);
            var cultureInfoPesos = new CultureInfo("fil-PH");
            lblTotalValue.Text = string.Format(cultureInfoPesos, "Total Price: {0:C2}", totalPrice);

        }
    
    private void UpdateTotalValue()
        {
            // Sum the prices of each product (ignoring quantity)
            decimal totalPrice = products.Sum(p => p.Price);

            // Use the "fil-PH" culture for Philippine Pesos
            var cultureInfoPesos = new CultureInfo("fil-PH");

            // Update the label to show the total price in Philippine Pesos (₱)
            lblTotalValue.Text = string.Format(cultureInfoPesos, "Total Price: {0:C2}", totalPrice);
        }

        private void txtCategory_TextChanged(object sender, EventArgs e)
        {

        }
    }
}



