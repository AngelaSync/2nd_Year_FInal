﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InventoryManagementApp
{
    
 
    
        public class Product
        {
        // Fields – private variables to store product info
        //Using private fields ensures encapsulation (control over access).
        private string name;
            private string category;
            private int quantity;
            private decimal price; 
        // Constructor
        // The constructor initializes a new Product with the given values.
        public Product(string name, string category, int quantity, decimal price)
            {
                Name = name;
                Category = category;
                Quantity = quantity;
                Price = price;
            }
            // Properties with encapsulation
            // Properties act as controlled gateways to the fields.
            // The set block ensures invalid data (like empty name) cannot be assigned.
            public string Name
            {
                get { return name; }
                set
                {
                    if (!string.IsNullOrEmpty(value))
                        name = value;
                    else
                        throw new ArgumentException("Name cannot be empty");
                }
            }
            public string Category
            {
                get { return category; }
                set
                {
                    if (!string.IsNullOrEmpty(value))
                        category = value;
                    else
                        throw new ArgumentException("Category cannot be empty");
                }
            }
            public int Quantity
            {
                get { return quantity; }
                set
                {
                    if (value >= 0)
                        quantity = value;
                    else
                        throw new ArgumentException("Quantity cannot be negative");
                }
            }
            public decimal Price
            {
                get { return price; }
                set
                {
                    if (value >= 0)
                        price = value;
                    else
                        throw new ArgumentException("Price cannot be negative");
                }
            }
            // Override ToString for display in ListBox
            public override string ToString()
            {
                return $"{Name} - {Category} - Qty: {Quantity} - Price: ${Price}";
        }
    }
    }

    
   





