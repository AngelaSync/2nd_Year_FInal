namespace StandardCalculatorr
{
    public partial class StandardCalcu : Form
    {
        public StandardCalcu()
        {
            InitializeComponent();
        }

        double num1, num2, result;
        bool isNewEntry = true;


        private void Btn_Del_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Lbl_Sum.Text) && Lbl_Sum.Text.Length > 1)
            {
                Lbl_Sum.Text = Lbl_Sum.Text.Substring(0, Lbl_Sum.Text.Length - 1);
            }
            else
            {
                Lbl_Sum.Text = "0";
                isNewEntry = true;
            }
        }

        private void Btn_1_Click(object sender, EventArgs e)
        {
            if (isNewEntry)
            {
                Lbl_Sum.Text = "";
                isNewEntry = false;
            }

            Lbl_Sum.Text += Btn_1.Text;
            double.TryParse(Lbl_Sum.Text, out num1);
        }

        private void Btn_2_Click(object sender, EventArgs e)
        {
            if (isNewEntry)
            {
                Lbl_Sum.Text = "";
                isNewEntry = false;
            }

            Lbl_Sum.Text += Btn_2.Text;
            double.TryParse(Lbl_Sum.Text, out num1);
        }

        private void Btn_3_Click(object sender, EventArgs e)
        {
            if (isNewEntry)
            {
                Lbl_Sum.Text = "";
                isNewEntry = false;
            }

            Lbl_Sum.Text += Btn_3.Text;
            double.TryParse(Lbl_Sum.Text, out num1);
        }

        private void Btn_4_Click(object sender, EventArgs e)
        {
            if (isNewEntry)
            {
                Lbl_Sum.Text = "";
                isNewEntry = false;
            }

            Lbl_Sum.Text += Btn_4.Text;
            double.TryParse(Lbl_Sum.Text, out num1);
        }

        private void Btn_5_Click(object sender, EventArgs e)
        {
            if (isNewEntry)
            {
                Lbl_Sum.Text = "";
                isNewEntry = false;
            }

            Lbl_Sum.Text += Btn_5.Text;
            double.TryParse(Lbl_Sum.Text, out num1);
        }

        private void Btn_6_Click(object sender, EventArgs e)
        {
            if (isNewEntry)
            {
                Lbl_Sum.Text = "";
                isNewEntry = false;
            }

            Lbl_Sum.Text += Btn_6.Text;
            double.TryParse(Lbl_Sum.Text, out num1);
        }

        private void Btn_7_Click(object sender, EventArgs e)
        {
            if (isNewEntry)
            {
                Lbl_Sum.Text = "";
                isNewEntry = false;
            }

            Lbl_Sum.Text += Btn_7.Text;
            double.TryParse(Lbl_Sum.Text, out num1);
        }

        private void Btn_8_Click(object sender, EventArgs e)
        {
            if (isNewEntry)
            {
                Lbl_Sum.Text = "";
                isNewEntry = false;
            }

            Lbl_Sum.Text += Btn_8.Text;
            double.TryParse(Lbl_Sum.Text, out num1);
        }

        private void Btn_9_Click(object sender, EventArgs e)
        {
            if (isNewEntry)
            {
                Lbl_Sum.Text = "";
                isNewEntry = false;
            }

            Lbl_Sum.Text += Btn_9.Text;
            double.TryParse(Lbl_Sum.Text, out num1);
        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            //add button handler
            string expr = Lbl_Sum.Text;
            char[] operators = { '+', '-', 'x', '/' };

            // used to skip if a negative sign is at the start beside the second number
            int opIndex = expr.StartsWith("-") ? expr.IndexOfAny(operators, 1) : expr.IndexOfAny(operators);

            //icacalculate muna bago mag append ng new operator
            if (opIndex > 0 && opIndex < expr.Length - 1)
            {
                string left = expr.Substring(0, opIndex);
                string right = expr.Substring(opIndex + 1);
                char op = expr[opIndex];

                if (double.TryParse(left, out double num1) && double.TryParse(right, out double num2))
                {
                    double tempResult = 0;
                    switch (op)
                    {
                        case '+': tempResult = num1 + num2; break;
                        case '-': tempResult = num1 - num2; break;
                        case 'x': tempResult = num1 * num2; break;
                        case '/':
                            if (num2 == 0)
                            {
                                MessageBox.Show("Cannot divide by zero.");
                                return;
                            }
                            tempResult = num1 / num2;
                            break;
                    }
                    Lbl_Sum.Text = tempResult.ToString();
                }
            }

            //this appends the new operator
            Lbl_Sum.Text += "+";
            isNewEntry = false;
        }

        private void Btn_Sub_Click(object sender, EventArgs e)
        {
            //subtract button handler
            string expr = Lbl_Sum.Text;
            char[] operators = { '+', '-', 'x', '/' };

            int opIndex = expr.StartsWith("-") ? expr.IndexOfAny(operators, 1) : expr.IndexOfAny(operators);

            if (opIndex > 0 && opIndex < expr.Length - 1)
            {
                string left = expr.Substring(0, opIndex);
                string right = expr.Substring(opIndex + 1);
                char op = expr[opIndex];

                if (double.TryParse(left, out double num1) && double.TryParse(right, out double num2))
                {
                    double tempResult = 0;
                    switch (op)
                    {
                        case '+': tempResult = num1 + num2; break;
                        case '-': tempResult = num1 - num2; break;
                        case 'x': tempResult = num1 * num2; break;
                        case '/':
                            if (num2 == 0)
                            {
                                MessageBox.Show("Cannot divide by zero.");
                                return;
                            }
                            tempResult = num1 / num2;
                            break;
                    }
                    Lbl_Sum.Text = tempResult.ToString();
                }
            }

            Lbl_Sum.Text += "-";
            isNewEntry = false;
        }

        private void Btn_Multiply_Click(object sender, EventArgs e)
        {

            //multiply button handler
            string expr = Lbl_Sum.Text;
            char[] operators = { '+', '-', 'x', '/' };

            int opIndex = expr.StartsWith("-") ? expr.IndexOfAny(operators, 1) : expr.IndexOfAny(operators);

            if (opIndex > 0 && opIndex < expr.Length - 1)
            {
                string left = expr.Substring(0, opIndex);
                string right = expr.Substring(opIndex + 1);
                char op = expr[opIndex];

                if (double.TryParse(left, out double num1) && double.TryParse(right, out double num2))
                {
                    double tempResult = 0;
                    switch (op)
                    {
                        case '+': tempResult = num1 + num2; break;
                        case '-': tempResult = num1 - num2; break;
                        case 'x': tempResult = num1 * num2; break;
                        case '/':
                            if (num2 == 0)
                            {
                                MessageBox.Show("Cannot divide by zero.");
                                return;
                            }
                            tempResult = num1 / num2;
                            break;
                    }
                    Lbl_Sum.Text = tempResult.ToString();
                }
            }

            Lbl_Sum.Text += "x";
            isNewEntry = false;
        }

        private void Btn_Divide_Click(object sender, EventArgs e)
        {

            //divide button handler
            string expr = Lbl_Sum.Text;
            char[] operators = { '+', '-', 'x', '/' };

            int opIndex = expr.StartsWith("-") ? expr.IndexOfAny(operators, 1) : expr.IndexOfAny(operators);

            if (opIndex > 0 && opIndex < expr.Length - 1)
            {
                string left = expr.Substring(0, opIndex);
                string right = expr.Substring(opIndex + 1);
                char op = expr[opIndex];

                if (double.TryParse(left, out double num1) && double.TryParse(right, out double num2))
                {
                    double tempResult = 0;
                    switch (op)
                    {
                        case '+': tempResult = num1 + num2; break;
                        case '-': tempResult = num1 - num2; break;
                        case 'x': tempResult = num1 * num2; break;
                        case '/':
                            if (num2 == 0)
                            {
                                MessageBox.Show("Cannot divide by zero.");
                                return;
                            }
                            tempResult = num1 / num2;
                            break;
                    }
                    Lbl_Sum.Text = tempResult.ToString();
                }
            }

            Lbl_Sum.Text += "/";
            isNewEntry = false;
        }

        private void Btn_Sum_Click(object sender, EventArgs e)
        {
            string expr = Lbl_Sum.Text;
            char[] operators = { '+', '-', 'x', '/' };

            // If the first character is '-', skip it for operator search
            int opIndex = expr.StartsWith("-") ? expr.IndexOfAny(operators, 1) : expr.IndexOfAny(operators);

            // para macheck kung valid ba yung expression
            if (opIndex <= 0 || opIndex >= expr.Length - 1)
            {
                MessageBox.Show("Invalid expression.");
                return;
            }

            string left = expr.Substring(0, opIndex);
            string right = expr.Substring(opIndex + 1);
            char op = expr[opIndex];

            if ((op == '+' || op == '-') && right.Length > 1 && (right[0] == '-' || right[0] == '+'))
            {
                // para magamit ang mga cases like x+-n, x--n, x++n
            }

            //parsing the numbers
            if (!double.TryParse(left, out num1) || !double.TryParse(right, out num2))
            {
                MessageBox.Show("Invalid numbers.");
                return;
            }

            switch (op)
            {

                //this is the handler for the operations
                case '+':
                    result = num1 + num2;
                    break;
                case '-':
                    result = num1 - num2;
                    break;
                case 'x':
                    result = num1 * num2;
                    break;
                case '/':
                    if (num2 == 0)
                    {
                        MessageBox.Show("Cannot divide by zero.");
                        return;
                    }
                    result = num1 / num2;
                    break;
            }

            Lbl_Sum.Text = result.ToString();
            isNewEntry = true;
        }

        private void Btn_Fract_Click(object sender, EventArgs e)
        {
            int lastOp = Math.Max(
                Math.Max(Lbl_Sum.Text.LastIndexOf('+'), Lbl_Sum.Text.LastIndexOf('-')),
                    Math.Max(Lbl_Sum.Text.LastIndexOf('x'), Lbl_Sum.Text.LastIndexOf('/'))
                    );

            string currentNumber = lastOp >= 0 ? Lbl_Sum.Text.Substring(lastOp + 1) : Lbl_Sum.Text;

            if (double.TryParse(currentNumber, out double value))
            {
                if (value == 0)
                {
                    MessageBox.Show("Cannot divide by zero.");
                    return;
                }
                double reciprocal = 1.0 / value;
                // Replace the current number with its reciprocal
                if (lastOp >= 0)
                    Lbl_Sum.Text = Lbl_Sum.Text.Substring(0, lastOp + 1) + reciprocal.ToString();
                else
                    Lbl_Sum.Text = reciprocal.ToString();
            }
            else
            {
                MessageBox.Show("Invalid number for reciprocal.");
            }
        }

        private void Btn_Dot_Click(object sender, EventArgs e)
        {
            //para makita kung meron na bang decimal number
            int lastOp = Math.Max(
                Math.Max(Lbl_Sum.Text.LastIndexOf('+'), Lbl_Sum.Text.LastIndexOf('-')),
                Math.Max(Lbl_Sum.Text.LastIndexOf('x'), Lbl_Sum.Text.LastIndexOf('/'))
            );

            string currentNumber = lastOp >= 0 ? Lbl_Sum.Text.Substring(lastOp + 1) : Lbl_Sum.Text;

            // ito naman yung logic para makita kung meron na bang decimal point
            if (!currentNumber.Contains("."))
            {
                Lbl_Sum.Text += ".";
            }
        }

        private void Btn_C_Click(object sender, EventArgs e)
        {

            //to clear everything
            Lbl_Sum.Text = "0";
            num1 = 0;
            num2 = 0;
            result = 0;
            isNewEntry = true;
        }

        private void Btn_Sqrd_Click(object sender, EventArgs e)
        {
            //square button handler
            int lastOp = Math.Max(
                Math.Max(Lbl_Sum.Text.LastIndexOf('+'), Lbl_Sum.Text.LastIndexOf('-')),
                Math.Max(Lbl_Sum.Text.LastIndexOf('x'), Lbl_Sum.Text.LastIndexOf('/'))
            );

            string currentNumber = lastOp >= 0 ? Lbl_Sum.Text.Substring(lastOp + 1) : Lbl_Sum.Text;

            if (double.TryParse(currentNumber, out double value))
            {
                double squared = value * value;
                //para mapalitan yung number nung squared value
                if (lastOp >= 0)
                    Lbl_Sum.Text = Lbl_Sum.Text.Substring(0, lastOp + 1) + squared.ToString();
                else
                    Lbl_Sum.Text = squared.ToString();
            }
            else
            {
                MessageBox.Show("Invalid number for squaring.");
            }
        }

        private void BtnSqr_Root_Click(object sender, EventArgs e)
        {
            int lastOp = Math.Max(
                Math.Max(Lbl_Sum.Text.LastIndexOf('+'), Lbl_Sum.Text.LastIndexOf('-')),
                Math.Max(Lbl_Sum.Text.LastIndexOf('x'), Lbl_Sum.Text.LastIndexOf('/'))
            );

            string currentNumber = lastOp >= 0 ? Lbl_Sum.Text.Substring(lastOp + 1) : Lbl_Sum.Text;

            if (double.TryParse(currentNumber, out double value))
            {
                if (value < 0)
                {
                    MessageBox.Show("Cannot take square root of a negative number.");
                    return;
                }
                double sqrt = Math.Sqrt(value);
                // Replace the current number with its square root
                if (lastOp >= 0)
                    Lbl_Sum.Text = Lbl_Sum.Text.Substring(0, lastOp + 1) + sqrt.ToString();
                else
                    Lbl_Sum.Text = sqrt.ToString();
            }
            else
            {
                MessageBox.Show("Invalid number for square root.");
            }
        }

        private void btnMe_C_Click(object sender, EventArgs e)
        {
            if (isNewEntry && double.TryParse(Lbl_Sum.Text, out double value))
            {
                double percentResult = value / 100.0;
                Lbl_Sum.Text = percentResult.ToString();
                isNewEntry = true;
            }
            else
            {
                // If not calculated yet, revert to zero
                Lbl_Sum.Text = "0";
                isNewEntry = true;
            }
        }

        private void Btn_PosNeg_Click(object sender, EventArgs e)
        {
            int lastOp = Math.Max(
                Math.Max(Lbl_Sum.Text.LastIndexOf('+'), Lbl_Sum.Text.LastIndexOf('-')),
                Math.Max(Lbl_Sum.Text.LastIndexOf('x'), Lbl_Sum.Text.LastIndexOf('/'))
            );

            string currentNumber = lastOp >= 0 ? Lbl_Sum.Text.Substring(lastOp + 1) : Lbl_Sum.Text;

            if (double.TryParse(currentNumber, out double value))
            {
                value = -value;
                string newNumber = value.ToString();

                // Replace the current number with its negated value
                if (lastOp >= 0)
                    Lbl_Sum.Text = Lbl_Sum.Text.Substring(0, lastOp + 1) + newNumber;
                else
                    Lbl_Sum.Text = newNumber;
            }
            else
            {
                MessageBox.Show("Invalid number for sign change.");
            }
        }
    }
}
