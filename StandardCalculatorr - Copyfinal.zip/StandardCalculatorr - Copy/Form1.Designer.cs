﻿
namespace StandardCalculatorr
{
    partial class StandardCalcu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StandardCalcu));
            LblType = new Label();
            Btn_OnTop = new Button();
            groupBox1 = new GroupBox();
            Btn_MeC = new Button();
            Btn_MR = new Button();
            BtnM_Add = new Button();
            Btn_Me = new Button();
            Btn_MS = new Button();
            BtnM_Subt = new Button();
            Lbl_Sum = new Label();
            groupBox2 = new GroupBox();
            Btn_Sum = new Button();
            Btn_Dot = new Button();
            Btn_0 = new Button();
            Btn_PosNeg = new Button();
            Btn_Add = new Button();
            Btn_3 = new Button();
            Btn_2 = new Button();
            Btn_1 = new Button();
            Btn_Sub = new Button();
            Btn_6 = new Button();
            Btn_5 = new Button();
            Btn_4 = new Button();
            Btn_Multiply = new Button();
            Btn_9 = new Button();
            Btn_8 = new Button();
            Btn_7 = new Button();
            Btn_Divide = new Button();
            BtnSqr_Root = new Button();
            Btn_Sqrd = new Button();
            Btn_Fract = new Button();
            Btn_Del = new Button();
            Btn_C = new Button();
            Btn_CE = new Button();
            btnMe_C = new Button();
            Btn_Hist = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // LblType
            // 
            LblType.AutoSize = true;
            LblType.Font = new Font("Microsoft Sans Serif", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 134);
            LblType.Location = new Point(50, 22);
            LblType.Margin = new Padding(4, 0, 4, 0);
            LblType.Name = "LblType";
            LblType.Size = new Size(189, 46);
            LblType.TabIndex = 0;
            LblType.Text = "Standard";
            // 
            // Btn_OnTop
            // 
            Btn_OnTop.BackColor = Color.SteelBlue;
            Btn_OnTop.BackgroundImageLayout = ImageLayout.Stretch;
            Btn_OnTop.FlatAppearance.BorderSize = 0;
            Btn_OnTop.FlatStyle = FlatStyle.Flat;
            Btn_OnTop.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Btn_OnTop.ForeColor = Color.MistyRose;
            Btn_OnTop.Image = (Image)resources.GetObject("Btn_OnTop.Image");
            Btn_OnTop.Location = new Point(234, 22);
            Btn_OnTop.Margin = new Padding(4);
            Btn_OnTop.Name = "Btn_OnTop";
            Btn_OnTop.Size = new Size(42, 44);
            Btn_OnTop.TabIndex = 1;
            Btn_OnTop.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(Btn_MeC);
            groupBox1.Controls.Add(Btn_MR);
            groupBox1.Controls.Add(BtnM_Add);
            groupBox1.FlatStyle = FlatStyle.Flat;
            groupBox1.Location = new Point(1, 182);
            groupBox1.Margin = new Padding(4);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4);
            groupBox1.Size = new Size(494, 68);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            // 
            // Btn_MeC
            // 
            Btn_MeC.BackColor = Color.SteelBlue;
            Btn_MeC.FlatAppearance.BorderSize = 0;
            Btn_MeC.FlatStyle = FlatStyle.Flat;
            Btn_MeC.ForeColor = Color.MistyRose;
            Btn_MeC.Location = new Point(14, 22);
            Btn_MeC.Margin = new Padding(4);
            Btn_MeC.Name = "Btn_MeC";
            Btn_MeC.Size = new Size(71, 35);
            Btn_MeC.TabIndex = 0;
            Btn_MeC.Text = "MC";
            Btn_MeC.UseVisualStyleBackColor = false;
            Btn_MeC.Click += button1_Click;
            // 
            // Btn_MR
            // 
            Btn_MR.BackColor = Color.SteelBlue;
            Btn_MR.FlatAppearance.BorderSize = 0;
            Btn_MR.FlatStyle = FlatStyle.Flat;
            Btn_MR.ForeColor = Color.MistyRose;
            Btn_MR.Location = new Point(90, 21);
            Btn_MR.Margin = new Padding(4);
            Btn_MR.Name = "Btn_MR";
            Btn_MR.Size = new Size(68, 34);
            Btn_MR.TabIndex = 1;
            Btn_MR.Text = "MR";
            Btn_MR.UseVisualStyleBackColor = false;
            // 
            // BtnM_Add
            // 
            BtnM_Add.BackColor = Color.SteelBlue;
            BtnM_Add.FlatAppearance.BorderSize = 0;
            BtnM_Add.FlatStyle = FlatStyle.Flat;
            BtnM_Add.ForeColor = Color.MistyRose;
            BtnM_Add.Location = new Point(174, 21);
            BtnM_Add.Margin = new Padding(4);
            BtnM_Add.Name = "BtnM_Add";
            BtnM_Add.Size = new Size(68, 34);
            BtnM_Add.TabIndex = 2;
            BtnM_Add.Text = "M+";
            BtnM_Add.UseVisualStyleBackColor = false;
            // 
            // Btn_Me
            // 
            Btn_Me.BackColor = Color.SteelBlue;
            Btn_Me.FlatAppearance.BorderSize = 0;
            Btn_Me.FlatStyle = FlatStyle.Flat;
            Btn_Me.ForeColor = Color.MistyRose;
            Btn_Me.Location = new Point(414, 201);
            Btn_Me.Margin = new Padding(4);
            Btn_Me.Name = "Btn_Me";
            Btn_Me.Size = new Size(68, 34);
            Btn_Me.TabIndex = 5;
            Btn_Me.Text = "M▼";
            Btn_Me.UseVisualStyleBackColor = false;
            // 
            // Btn_MS
            // 
            Btn_MS.BackColor = Color.SteelBlue;
            Btn_MS.FlatAppearance.BorderSize = 0;
            Btn_MS.FlatStyle = FlatStyle.Flat;
            Btn_MS.ForeColor = Color.MistyRose;
            Btn_MS.Location = new Point(339, 202);
            Btn_MS.Margin = new Padding(4);
            Btn_MS.Name = "Btn_MS";
            Btn_MS.Size = new Size(68, 34);
            Btn_MS.TabIndex = 4;
            Btn_MS.Text = "MS";
            Btn_MS.UseVisualStyleBackColor = false;
            // 
            // BtnM_Subt
            // 
            BtnM_Subt.BackColor = Color.SteelBlue;
            BtnM_Subt.FlatAppearance.BorderSize = 0;
            BtnM_Subt.FlatStyle = FlatStyle.Flat;
            BtnM_Subt.ForeColor = Color.MistyRose;
            BtnM_Subt.Location = new Point(256, 202);
            BtnM_Subt.Margin = new Padding(4);
            BtnM_Subt.Name = "BtnM_Subt";
            BtnM_Subt.Size = new Size(68, 34);
            BtnM_Subt.TabIndex = 3;
            BtnM_Subt.Text = "M-";
            BtnM_Subt.UseVisualStyleBackColor = false;
            // 
            // Lbl_Sum
            // 
            Lbl_Sum.AutoSize = true;
            Lbl_Sum.Font = new Font("Microsoft Sans Serif", 25.8000011F, FontStyle.Bold, GraphicsUnit.Point, 134);
            Lbl_Sum.Location = new Point(5, 119);
            Lbl_Sum.Margin = new Padding(4, 0, 4, 0);
            Lbl_Sum.Name = "Lbl_Sum";
            Lbl_Sum.Size = new Size(55, 59);
            Lbl_Sum.TabIndex = 5;
            Lbl_Sum.Text = "0";
            Lbl_Sum.TextAlign = ContentAlignment.MiddleRight;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.LightSkyBlue;
            groupBox2.Controls.Add(Btn_Sum);
            groupBox2.Controls.Add(Btn_Dot);
            groupBox2.Controls.Add(Btn_0);
            groupBox2.Controls.Add(Btn_PosNeg);
            groupBox2.Controls.Add(Btn_Add);
            groupBox2.Controls.Add(Btn_3);
            groupBox2.Controls.Add(Btn_2);
            groupBox2.Controls.Add(Btn_1);
            groupBox2.Controls.Add(Btn_Sub);
            groupBox2.Controls.Add(Btn_6);
            groupBox2.Controls.Add(Btn_5);
            groupBox2.Controls.Add(Btn_4);
            groupBox2.Controls.Add(Btn_Multiply);
            groupBox2.Controls.Add(Btn_9);
            groupBox2.Controls.Add(Btn_8);
            groupBox2.Controls.Add(Btn_7);
            groupBox2.Controls.Add(Btn_Divide);
            groupBox2.Controls.Add(BtnSqr_Root);
            groupBox2.Controls.Add(Btn_Sqrd);
            groupBox2.Controls.Add(Btn_Fract);
            groupBox2.Controls.Add(Btn_Del);
            groupBox2.Controls.Add(Btn_C);
            groupBox2.Controls.Add(Btn_CE);
            groupBox2.Controls.Add(btnMe_C);
            groupBox2.Location = new Point(1, 258);
            groupBox2.Margin = new Padding(4);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(4);
            groupBox2.Size = new Size(494, 560);
            groupBox2.TabIndex = 6;
            groupBox2.TabStop = false;
            // 
            // Btn_Sum
            // 
            Btn_Sum.BackColor = Color.LightSteelBlue;
            Btn_Sum.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Sum.Image = (Image)resources.GetObject("Btn_Sum.Image");
            Btn_Sum.ImageAlign = ContentAlignment.TopCenter;
            Btn_Sum.Location = new Point(371, 472);
            Btn_Sum.Margin = new Padding(4);
            Btn_Sum.Name = "Btn_Sum";
            Btn_Sum.Size = new Size(121, 82);
            Btn_Sum.TabIndex = 23;
            Btn_Sum.UseVisualStyleBackColor = false;
            Btn_Sum.Click += Btn_Sum_Click;
            // 
            // Btn_Dot
            // 
            Btn_Dot.BackColor = Color.LightSkyBlue;
            Btn_Dot.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_Dot.Location = new Point(249, 472);
            Btn_Dot.Margin = new Padding(4);
            Btn_Dot.Name = "Btn_Dot";
            Btn_Dot.Size = new Size(121, 82);
            Btn_Dot.TabIndex = 22;
            Btn_Dot.Text = ".";
            Btn_Dot.UseVisualStyleBackColor = false;
            Btn_Dot.Click += Btn_Dot_Click;
            // 
            // Btn_0
            // 
            Btn_0.BackColor = Color.LightSkyBlue;
            Btn_0.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_0.Location = new Point(126, 472);
            Btn_0.Margin = new Padding(4);
            Btn_0.Name = "Btn_0";
            Btn_0.Size = new Size(121, 82);
            Btn_0.TabIndex = 21;
            Btn_0.Text = "0";
            Btn_0.UseVisualStyleBackColor = false;
            // 
            // Btn_PosNeg
            // 
            Btn_PosNeg.BackColor = Color.LightSkyBlue;
            Btn_PosNeg.Font = new Font("Segoe UI Semibold", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_PosNeg.Location = new Point(4, 472);
            Btn_PosNeg.Margin = new Padding(4);
            Btn_PosNeg.Name = "Btn_PosNeg";
            Btn_PosNeg.Size = new Size(121, 82);
            Btn_PosNeg.TabIndex = 20;
            Btn_PosNeg.Text = "⁺⁄₋";
            Btn_PosNeg.UseVisualStyleBackColor = false;
            Btn_PosNeg.Click += Btn_PosNeg_Click;
            // 
            // Btn_Add
            // 
            Btn_Add.BackColor = Color.LightSkyBlue;
            Btn_Add.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Add.Image = (Image)resources.GetObject("Btn_Add.Image");
            Btn_Add.Location = new Point(371, 382);
            Btn_Add.Margin = new Padding(4);
            Btn_Add.Name = "Btn_Add";
            Btn_Add.Size = new Size(121, 82);
            Btn_Add.TabIndex = 19;
            Btn_Add.UseVisualStyleBackColor = false;
            Btn_Add.Click += Btn_Add_Click;
            // 
            // Btn_3
            // 
            Btn_3.BackColor = Color.LightSkyBlue;
            Btn_3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_3.Location = new Point(249, 386);
            Btn_3.Margin = new Padding(4);
            Btn_3.Name = "Btn_3";
            Btn_3.Size = new Size(121, 82);
            Btn_3.TabIndex = 18;
            Btn_3.Text = "3";
            Btn_3.UseVisualStyleBackColor = false;
            Btn_3.Click += Btn_3_Click;
            // 
            // Btn_2
            // 
            Btn_2.BackColor = Color.LightSkyBlue;
            Btn_2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_2.Location = new Point(126, 382);
            Btn_2.Margin = new Padding(4);
            Btn_2.Name = "Btn_2";
            Btn_2.Size = new Size(121, 82);
            Btn_2.TabIndex = 17;
            Btn_2.Text = "2";
            Btn_2.UseVisualStyleBackColor = false;
            Btn_2.Click += Btn_2_Click;
            // 
            // Btn_1
            // 
            Btn_1.BackColor = Color.LightSkyBlue;
            Btn_1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_1.Location = new Point(4, 382);
            Btn_1.Margin = new Padding(4);
            Btn_1.Name = "Btn_1";
            Btn_1.Size = new Size(121, 82);
            Btn_1.TabIndex = 16;
            Btn_1.Text = "1";
            Btn_1.UseVisualStyleBackColor = false;
            Btn_1.Click += Btn_1_Click;
            // 
            // Btn_Sub
            // 
            Btn_Sub.BackColor = Color.LightSkyBlue;
            Btn_Sub.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Sub.Image = (Image)resources.GetObject("Btn_Sub.Image");
            Btn_Sub.Location = new Point(371, 292);
            Btn_Sub.Margin = new Padding(4);
            Btn_Sub.Name = "Btn_Sub";
            Btn_Sub.Size = new Size(121, 82);
            Btn_Sub.TabIndex = 15;
            Btn_Sub.UseVisualStyleBackColor = false;
            Btn_Sub.Click += Btn_Sub_Click;
            // 
            // Btn_6
            // 
            Btn_6.BackColor = Color.LightSkyBlue;
            Btn_6.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_6.Location = new Point(249, 292);
            Btn_6.Margin = new Padding(4);
            Btn_6.Name = "Btn_6";
            Btn_6.Size = new Size(121, 82);
            Btn_6.TabIndex = 14;
            Btn_6.Text = "6";
            Btn_6.UseVisualStyleBackColor = false;
            Btn_6.Click += Btn_6_Click;
            // 
            // Btn_5
            // 
            Btn_5.BackColor = Color.LightSkyBlue;
            Btn_5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_5.Location = new Point(126, 292);
            Btn_5.Margin = new Padding(4);
            Btn_5.Name = "Btn_5";
            Btn_5.Size = new Size(121, 82);
            Btn_5.TabIndex = 13;
            Btn_5.Text = "5";
            Btn_5.UseVisualStyleBackColor = false;
            Btn_5.Click += Btn_5_Click;
            // 
            // Btn_4
            // 
            Btn_4.BackColor = Color.LightSkyBlue;
            Btn_4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_4.Location = new Point(4, 292);
            Btn_4.Margin = new Padding(4);
            Btn_4.Name = "Btn_4";
            Btn_4.Size = new Size(121, 82);
            Btn_4.TabIndex = 12;
            Btn_4.Text = "4";
            Btn_4.UseVisualStyleBackColor = false;
            Btn_4.Click += Btn_4_Click;
            // 
            // Btn_Multiply
            // 
            Btn_Multiply.BackColor = Color.LightSkyBlue;
            Btn_Multiply.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Multiply.Image = (Image)resources.GetObject("Btn_Multiply.Image");
            Btn_Multiply.ImageAlign = ContentAlignment.TopCenter;
            Btn_Multiply.Location = new Point(371, 202);
            Btn_Multiply.Margin = new Padding(4);
            Btn_Multiply.Name = "Btn_Multiply";
            Btn_Multiply.Size = new Size(121, 82);
            Btn_Multiply.TabIndex = 11;
            Btn_Multiply.UseVisualStyleBackColor = false;
            Btn_Multiply.Click += Btn_Multiply_Click;
            // 
            // Btn_9
            // 
            Btn_9.BackColor = Color.LightSkyBlue;
            Btn_9.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_9.Location = new Point(249, 202);
            Btn_9.Margin = new Padding(4);
            Btn_9.Name = "Btn_9";
            Btn_9.Size = new Size(121, 82);
            Btn_9.TabIndex = 10;
            Btn_9.Text = "9";
            Btn_9.UseVisualStyleBackColor = false;
            Btn_9.Click += Btn_9_Click;
            // 
            // Btn_8
            // 
            Btn_8.BackColor = Color.LightSkyBlue;
            Btn_8.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_8.Location = new Point(126, 202);
            Btn_8.Margin = new Padding(4);
            Btn_8.Name = "Btn_8";
            Btn_8.Size = new Size(121, 82);
            Btn_8.TabIndex = 9;
            Btn_8.Text = "8";
            Btn_8.UseVisualStyleBackColor = false;
            Btn_8.Click += Btn_8_Click;
            // 
            // Btn_7
            // 
            Btn_7.BackColor = Color.LightSkyBlue;
            Btn_7.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_7.Location = new Point(4, 202);
            Btn_7.Margin = new Padding(4);
            Btn_7.Name = "Btn_7";
            Btn_7.Size = new Size(121, 82);
            Btn_7.TabIndex = 8;
            Btn_7.Text = "7";
            Btn_7.UseVisualStyleBackColor = false;
            Btn_7.Click += Btn_7_Click;
            // 
            // Btn_Divide
            // 
            Btn_Divide.BackColor = Color.LightSkyBlue;
            Btn_Divide.Font = new Font("Segoe UI Semibold", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Divide.Image = (Image)resources.GetObject("Btn_Divide.Image");
            Btn_Divide.Location = new Point(371, 112);
            Btn_Divide.Margin = new Padding(4);
            Btn_Divide.Name = "Btn_Divide";
            Btn_Divide.Size = new Size(121, 82);
            Btn_Divide.TabIndex = 7;
            Btn_Divide.TextAlign = ContentAlignment.TopCenter;
            Btn_Divide.UseVisualStyleBackColor = false;
            Btn_Divide.Click += Btn_Divide_Click;
            // 
            // BtnSqr_Root
            // 
            BtnSqr_Root.BackColor = Color.LightSkyBlue;
            BtnSqr_Root.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            BtnSqr_Root.Location = new Point(249, 112);
            BtnSqr_Root.Margin = new Padding(4);
            BtnSqr_Root.Name = "BtnSqr_Root";
            BtnSqr_Root.Size = new Size(121, 82);
            BtnSqr_Root.TabIndex = 6;
            BtnSqr_Root.Text = "²√x";
            BtnSqr_Root.UseVisualStyleBackColor = false;
            BtnSqr_Root.Click += BtnSqr_Root_Click;
            // 
            // Btn_Sqrd
            // 
            Btn_Sqrd.BackColor = Color.LightSkyBlue;
            Btn_Sqrd.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_Sqrd.Location = new Point(126, 112);
            Btn_Sqrd.Margin = new Padding(4);
            Btn_Sqrd.Name = "Btn_Sqrd";
            Btn_Sqrd.Size = new Size(121, 82);
            Btn_Sqrd.TabIndex = 5;
            Btn_Sqrd.Text = "x²";
            Btn_Sqrd.UseVisualStyleBackColor = false;
            Btn_Sqrd.Click += Btn_Sqrd_Click;
            // 
            // Btn_Fract
            // 
            Btn_Fract.BackColor = Color.LightSkyBlue;
            Btn_Fract.Font = new Font("Segoe UI Semibold", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Fract.Location = new Point(4, 112);
            Btn_Fract.Margin = new Padding(4);
            Btn_Fract.Name = "Btn_Fract";
            Btn_Fract.Size = new Size(121, 82);
            Btn_Fract.TabIndex = 4;
            Btn_Fract.Text = "¹⁄ₓ";
            Btn_Fract.UseVisualStyleBackColor = false;
            Btn_Fract.Click += Btn_Fract_Click;
            // 
            // Btn_Del
            // 
            Btn_Del.BackColor = Color.LightSkyBlue;
            Btn_Del.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_Del.Image = (Image)resources.GetObject("Btn_Del.Image");
            Btn_Del.Location = new Point(371, 22);
            Btn_Del.Margin = new Padding(4);
            Btn_Del.Name = "Btn_Del";
            Btn_Del.Size = new Size(121, 82);
            Btn_Del.TabIndex = 3;
            Btn_Del.UseVisualStyleBackColor = false;
            Btn_Del.Click += Btn_Del_Click;
            // 
            // Btn_C
            // 
            Btn_C.BackColor = Color.LightSkyBlue;
            Btn_C.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_C.Location = new Point(249, 22);
            Btn_C.Margin = new Padding(4);
            Btn_C.Name = "Btn_C";
            Btn_C.Size = new Size(121, 82);
            Btn_C.TabIndex = 2;
            Btn_C.Text = "C";
            Btn_C.UseVisualStyleBackColor = false;
            Btn_C.Click += Btn_C_Click;
            // 
            // Btn_CE
            // 
            Btn_CE.BackColor = Color.LightSkyBlue;
            Btn_CE.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            Btn_CE.Location = new Point(126, 22);
            Btn_CE.Margin = new Padding(4);
            Btn_CE.Name = "Btn_CE";
            Btn_CE.Size = new Size(121, 82);
            Btn_CE.TabIndex = 1;
            Btn_CE.Text = "CE";
            Btn_CE.UseVisualStyleBackColor = false;
            // 
            // btnMe_C
            // 
            btnMe_C.BackColor = Color.LightSkyBlue;
            btnMe_C.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnMe_C.Location = new Point(4, 22);
            btnMe_C.Margin = new Padding(4);
            btnMe_C.Name = "btnMe_C";
            btnMe_C.Size = new Size(121, 82);
            btnMe_C.TabIndex = 0;
            btnMe_C.Text = "%";
            btnMe_C.UseVisualStyleBackColor = false;
            btnMe_C.Click += btnMe_C_Click;
            // 
            // Btn_Hist
            // 
            Btn_Hist.BackColor = Color.SteelBlue;
            Btn_Hist.FlatAppearance.BorderSize = 0;
            Btn_Hist.FlatStyle = FlatStyle.Flat;
            Btn_Hist.ForeColor = Color.MistyRose;
            Btn_Hist.Image = (Image)resources.GetObject("Btn_Hist.Image");
            Btn_Hist.Location = new Point(421, 14);
            Btn_Hist.Margin = new Padding(4);
            Btn_Hist.Name = "Btn_Hist";
            Btn_Hist.Size = new Size(72, 59);
            Btn_Hist.TabIndex = 2;
            Btn_Hist.Text = " ";
            Btn_Hist.UseVisualStyleBackColor = false;
            // 
            // StandardCalcu
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SteelBlue;
            ClientSize = new Size(496, 820);
            Controls.Add(Btn_Me);
            Controls.Add(Btn_MS);
            Controls.Add(groupBox2);
            Controls.Add(BtnM_Subt);
            Controls.Add(Lbl_Sum);
            Controls.Add(groupBox1);
            Controls.Add(Btn_Hist);
            Controls.Add(Btn_OnTop);
            Controls.Add(LblType);
            ForeColor = Color.MistyRose;
            Margin = new Padding(4);
            Name = "StandardCalcu";
            Text = "Standard Calculator";
            groupBox1.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private Label LblType;
        private Button Btn_OnTop;
        private GroupBox groupBox1;
        private Button Btn_MeC;
        private Button Btn_Me;
        private Button Btn_MS;
        private Button BtnM_Subt;
        private Button BtnM_Add;
        private Button Btn_MR;
        private Label Lbl_Sum;
        private GroupBox groupBox2;
        private Button btnMe_C;
        private Button Btn_Del;
        private Button Btn_C;
        private Button Btn_CE;
        private Button Btn_Sum;
        private Button Btn_Dot;
        private Button Btn_0;
        private Button Btn_PosNeg;
        private Button Btn_Add;
        private Button Btn_3;
        private Button Btn_2;
        private Button Btn_1;
        private Button Btn_Sub;
        private Button Btn_6;
        private Button Btn_5;
        private Button Btn_4;
        private Button Btn_Multiply;
        private Button Btn_9;
        private Button Btn_8;
        private Button Btn_7;
        private Button Btn_Divide;
        private Button BtnSqr_Root;
        private Button Btn_Sqrd;
        private Button Btn_Fract;
        private Button Btn_Hist;
    }
}
